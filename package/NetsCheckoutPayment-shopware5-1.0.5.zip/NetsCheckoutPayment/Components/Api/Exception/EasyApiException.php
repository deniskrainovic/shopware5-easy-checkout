<?php

namespace NetsCheckoutPayment\Components\Api\Exception;

class EasyApiException extends \Exception
{

}