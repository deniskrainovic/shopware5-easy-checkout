$(function() {

//	$('.content-main--inner').append('<div class="row"><div class="col-xl-12 ttop">111</div><div class="col-xl-6 ttmain">222</div><div class="col-xl-6"><div class="row"><div class="col-xl-12 sstop">333</div><div class="col-xl-12 ssbtm">444</div></div></div></div>');
    
	$('.product--table').appendTo('.ttop');
	$('.nets--panel').appendTo('.cenl');
	$('.information--panel-item').appendTo('.cenr');
	$('.table--actions, .tos--panel').hide();	
//	$('.confirm-address, .confirm-payment-shipping').appendTo('.ssbtm');
//	$('.is-act-confirmpage .checkout .checkout-main, .is-act-confirmpage .checkout .checkout-aside').css({
//		'margin-left' : '0', 
//		'padding' : '0', 
//		'flex' : '0 0 100%', 
//		'max-width' : '100%'
//	});
//	$('.checkout').css({'padding' : '70px 50px'});
//	$('.ssbtm .btn-light').css({'width' : '100%', 'border-color' : '#bcc1c7', 'text-align' : 'center'});

});
