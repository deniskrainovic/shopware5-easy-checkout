;(function ($, window) {
    'use strict';


})(jQuery, window);
